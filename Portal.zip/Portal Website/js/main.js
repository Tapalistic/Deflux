// If you don't want the particles, remove the code below!
// Do not delete this file unless you know what you're doing.

$.firefly({
	minPixel: 1,
	maxPixel: 3,
	total: 50
});